Replicare la struttura html della navbar presente nel file png, disponibile al download, senza usare le proprietà CSS.

**Suggerimento**
Per replicare lo scheletro html della `navbar `, prova a utilizzare il tag semantico `<nav>`. Per i link presenti nella navbar, invece, prova ad utilizzare una lista non ordinata.
