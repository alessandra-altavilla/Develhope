Replicare la struttura html della card presente nel file in con estensione .zip, disponibile al download, senza utilizzare un foglio di stile CSS.

**Suggerimento**
La card è un elemento riutilizzabile nel nostro sito, potrebbe essere assimilabile ad un articolo. Prova ad usare il tag semantico `<article>` per creare la struttura html.
