Aggiungi alla pagina `start.html` (che trovi nel file disponibile al download):
- Un pulsante disabilitato
- Un input field di tipo number con una label con un intervallo da 0 a 100 e con step di 2. L'input field dovrà avere l'autofocus all'apertura della pagina
- Una checkbox con relativa label (la checkbox dovrà già essere selezionata)
- Un input field di tipo date.
