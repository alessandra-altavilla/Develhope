Crea un pagina HTML per un blog, con le seguenti caratteristiche:
- La pagina dovrà contenere l'articolo, un footer e un form.
- L'articolo dovrò avere un titolo, un paragrafo e una immagine di sfondo.
- Il form dovrà avere un campo obbligatorio per l'inserimento della mail e un pulsante di invio. 

**Suggestion**
Usa quanto più possibile i tag semantici. Alcuni dei tag semantici che puoi utilizzare sono `<h1>`, `<main>`, `<article>`, `<footer>`.
