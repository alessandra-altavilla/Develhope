Crea un form di registrazione. Il form dovrà contenere i seguenti campi:
- Email
- Password
- Nome e Cognome
- Data di nascita
- Numero di telefono
- Una select con scelta di un piano di abbonamento: piano free, un gruppo con 3 piani con prezzo crescente, una checkbox per il piano Pro.
- Numero carta
- CVC
- Scadenza
- Indirizzo di fatturazione

**Suggerimento**
Per il selettore con scelta di un piano di abbonamento, ricorda che devi usare un tag `<select>`, con i tag `<option> `all'interno, per gestire un gruppo, invece, esiste il tag `<optgroup>`
