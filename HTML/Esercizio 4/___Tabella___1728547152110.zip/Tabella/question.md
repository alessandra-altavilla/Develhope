Creare una tabella composta da 3 colonne rappresentanti le entrate e uscite mensili di un utente, e un titolo
- La prima colonna contiene i nomi dei mesi
- La seconda colonna le entrate
- La terza colonna le uscite
- La prima riga dovrà avere l'header della tabella
- L'ultima riga dovrà contenere le somme dei valori (non usare JavaScript, ma solo testo `hardcoded`).

**Suggerimento**
All'interno del tag table, crea tre blocchi per l'intestazione, per il corpo e per il footer della tabella, attraverso rispettivamente i tag <thead>, <tbody>, <tfoot>
