# HTML Tags

Molti dei tag html possiedono una formattazione di base data loro dal browser. Cerca di replicare la stessa struttura html del file `solution.png `, utilizzando i tag corretti, che trovi nel file in formato zip disponibile al download.
`All'interno del head è presente il tag style, ignoralo per il momento`

Suggerimento:
Usa questa lista per aiutarti a trovare il tag corretto. Aiutati anche guardando l'immagine solution.png.
<https://www.w3schools.com/TAgs/default.asp>
