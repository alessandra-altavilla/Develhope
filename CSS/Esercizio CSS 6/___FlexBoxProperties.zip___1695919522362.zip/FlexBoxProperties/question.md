Replica il layout, utilizzando la proprietà CSS Flexbox, presente nell'immagine asset/layout1.png nel file zip disponibile al download.
