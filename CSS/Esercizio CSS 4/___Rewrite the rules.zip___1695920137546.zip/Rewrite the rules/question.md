Riscrivi le regole utilizzando custom properties.
**Suggestion**:

Usa il selettore :root, definendo lì tutte le proprietà e utilizzandole nei selettori body e .ball
