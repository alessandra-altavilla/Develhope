Editare il foglio di stile tale che

Le classi `link1`, `link2`, `link3` devono modificare colore del testo e padding in modo che:
- una classe erediti i valori dal proprio parent
- una classe imposti i valori a quelli iniziali
- una classe riporti le proprietà al loro valore naturale

I paragrafi contenuti nel contenitore di classe `content1` abbiano un bordo attorno a loro.

La classe `variant-em` deve dare uno sfondo `greenyellow`, un colore al testo nero, applicare il grassetto e avere
il `font-style` del parent

