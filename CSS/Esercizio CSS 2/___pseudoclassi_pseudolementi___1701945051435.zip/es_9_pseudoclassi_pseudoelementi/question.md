- Applica alla prima lettera del primo paragrafo il seguente stile:

```css
{
	float: left;
	color: darkred;
	border: 3px ridge darkgoldenrod;
	padding: 16px;
	background-color: gold;
	margin: 8px;
}
```

 - Aggiungi al `blockquote` delle virgolette prima e dopo il testo;
 - Il link in fondo, deve cambiare colore al passaggio del mouse su di esso. Deve anche avere un colore diverso se è già stato visitato
