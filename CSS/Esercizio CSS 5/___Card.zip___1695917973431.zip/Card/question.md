Partendo dalla card che hai creato nell'esercizio dell'unità HTML, aggiungi le proprietà CSS. Guarda il layout nel file xample.png presente nel file zip disponibile al download.

**Suggerimento**:

Prova rendere la card responsiva, in modo tale da adattarla al suo container.
