Partendo dalla barra di navigazione che hai creato nell'esercizio HTML chiamato 'Navbar', aggiungi le proprietà CSS. Il pulsante di ricerca dovrebbe avere un effetto di hover (sfondo verde e testo bianco al passaggio del mouse).

**Suggestion**:
Utilizza le classi per applicare le regole CSS invece degli id, dei tag o dello stile inline.
