Data la tabella, creare un foglio di stile tale che:
 - La tabella abbia un bordo di 1px di colore #263238 e sia larga la metà della pagina.
 - Il titolo della tabella deve essere di colore #263238,in grassetto e grandezza 18px. Aggiungere inoltre un margine per staccare il testo dalla tabella
 - L'header della tabella abbia colore di sfondo #455a64 e testo bianco con peso 700.
 - Le righe della tabella abbiano colore di sfondo alternato tra #eceff1 e #b0bec5.
 - L'ultima riga della tabella abbia testo con peso 800 e sfondo di colore #78909c.
 - Nel corpo della tabella la colonna delle entrate ha un testo di colore #003300.
 - Nel corpo della tabella la colonna delle uscite ha un testo di colore #7f0000.
 - I valori numerici sono allineati a destra.
