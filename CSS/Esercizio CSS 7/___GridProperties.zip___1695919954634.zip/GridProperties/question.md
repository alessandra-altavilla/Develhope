Cerca di replicare il layout nell'immagine asset/layout4.png utilizzando le proprietà CSS Grid. I blocchi verdi e arancioni sono alti la metà dei blocchi gialli e rossi.
