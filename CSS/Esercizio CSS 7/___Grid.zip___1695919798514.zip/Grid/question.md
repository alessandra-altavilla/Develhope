Guarda il layout nell'immagine di esempio (example.png nel file zip disponibile al download) e cerca di replicarlo utilizzando le proprietà CSS Grid.

**Suggestion**:
La griglia che contiene tutti i numeri dovrebbe avere 4 colonne. Assegna questa regola `grid-template-columns: repeat(4, 1fr)` al div in cui hai inserito i numeri
