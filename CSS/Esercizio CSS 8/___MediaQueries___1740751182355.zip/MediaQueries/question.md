Cerca di replicare il layout visualizzato nelle immagini asset/cards-desktop.jpg, cards-mobile.jpg (max-width: 375px), cards-tablet.jpg (max-width: 768px). La pagina creata dovrebbe essere responsiva, sia per la visualizzazione tablet (`(max-width: 768px)`) che per la visualizzazione mobile (`(max-width: 375px)`).

**Suggestion:**
Utilizza le regole dei Media Query per risolvere con successo l'esercizio.
